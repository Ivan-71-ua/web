/// <reference types="cypress" />

import '@cypress/code-coverage/support'

export {}
